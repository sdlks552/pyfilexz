import pygame
import time
import subprocess
import os
from zdypack import color
class fname:
    def __init__(self,path=''):
        self.runn=True
        self.path=path
    def filetype(self,fnames):
        png_list=['png','PNG','jpg','JPG','JPEG','bmp','BMP','gif','GIF','webp','WEBP']
        txt_list=['txt']
        ppt_list=['ppt','pptx']
        doc_list=['doc','docx']
        xls_list=['xls','xlsx']
        zi_list=['zip','rar','7z','tar','gz','bz2','jar','cab','lzo','xz','lrz']
        mu_list=['MP3','mp3','WMA','wma','AAC','aac','FLAC','flac','APE','ape','WAV','wav','MIDI','midi','CDA','cda','NCM','ncm','OGG','ogg','MFLAC','mflac']
        vi_list=['AVI','avi','WMV','wmv','MPEG','mpeg','MOV','mov','RM','rm','RMVB','rmvb','FLV','flv','F4V','f4v','MP4','mp4','MKV','mkv','3GP','3gp','3GPP','3gpp','OGG','ogg','MOD','mod']
        ap_list=['apk','APK']
        ht_list=['html','mht','HTML','MHT']
        xmin_list=['xmind','XMIND']
        pathd_split=fnames.split('.')[-1].lower()
        if pathd_split in png_list:
            types='picture'
        elif pathd_split in txt_list:
            types='text'
        elif pathd_split in ppt_list:
            types='ppt'
        elif pathd_split in doc_list:
            types='doc'
        elif pathd_split in xls_list:
            types='xls'
        elif pathd_split in zi_list:
            types='zip'
        elif pathd_split in mu_list:
            types='music'
        elif pathd_split in vi_list:
            types='video'
        elif pathd_split in ap_list:
            types='apk'
        elif pathd_split in ht_list:
            types='html'
        elif pathd_split in xmin_list:
            types='xmaind'
        else:
            types=None
        return types
    def xuanze(self):
        pygame.init()
        screen=pygame.display.set_mode((1080,2335))
        #screen.fill((255,255,255))
        pygame.display.flip()
        #颜色赋值
        white=color.color('白色').color_RGB()
        black=color.color('黑色').color_RGB()
        dqblue=color.color('道奇蓝').color_RGB()
        #定义字体
        def fonts(px,colors,text,numb=100):
            fontc=pygame.font.Font('font/lianxiangxiaoxinheiticuti.ttf',px)
            if len(text)>numb:
                text=f'{text[0:len(text)]}...'
            tfont=fontc.render(text,True,colors)
            return tfont
        #图片加载
        backdir=pygame.image.load('filetb/backdir')
        xzfile=pygame.image.load('filetb/xzfile')
        quitimg=pygame.image.load('filetb/quit')
        up_img=pygame.image.load('filetb/up_tb')
        down_img=pygame.image.load('filetb/down_tb')
        storage_img=pygame.image.load('filetb/storage')
        home_img=pygame.image.load('filetb/home')
        dirs_img=pygame.image.load('filetb/dirs')
        weifile=pygame.image.load('filetb/weizhi')
        picture=pygame.image.load('filetb/picture')
        txt_img=pygame.image.load('filetb/txt')
        ppt_img=pygame.image.load('filetb/ppt')
        doc_img=pygame.image.load('filetb/doc')
        xls_img=pygame.image.load('filetb/xls')
        zip_img=pygame.image.load('filetb/zip')
        apk_img=pygame.image.load('filetb/apk')
        video_img=pygame.image.load('filetb/video')
        music_img=pygame.image.load('filetb/music')
        xmind_img=pygame.image.load('filetb/xmind')
        html_img=pygame.image.load('filetb/html')
        #图片处理
        backdir=pygame.transform.rotozoom(backdir,0,0.12)
        xzfile=pygame.transform.rotozoom(xzfile,0,0.35)
        quitimg=pygame.transform.rotozoom(quitimg,0,0.35)
        up_img=pygame.transform.rotozoom(up_img,0,0.06)
        down_img=pygame.transform.rotozoom(down_img,0,0.06)
        storage_img=pygame.transform.rotozoom(storage_img,0,0.08)
        home_img=pygame.transform.rotozoom(home_img,0,0.08)
        dirs_img=pygame.transform.rotozoom(dirs_img,0,0.08)
        weifile=pygame.transform.rotozoom(weifile,0,0.08)
        picture=pygame.transform.rotozoom(picture,0,0.08)
        txt_img=pygame.transform.rotozoom(txt_img,0,0.08)
        ppt_img=pygame.transform.rotozoom(ppt_img,0,0.08)
        doc_img=pygame.transform.rotozoom(doc_img,0,0.08)
        xls_img=pygame.transform.rotozoom(xls_img,0,0.08)
        zip_img=pygame.transform.rotozoom(zip_img,0,0.08)
        apk_img=pygame.transform.rotozoom(apk_img,0,0.08)
        video_img=pygame.transform.rotozoom(video_img,0,0.08)
        music_img=pygame.transform.rotozoom(music_img,0,0.08)
        xmind_img=pygame.transform.rotozoom(xmind_img,0,0.08)
        html_img=pygame.transform.rotozoom(html_img,0,0.08)
        #图片大小
        xfx,xfy=xzfile.get_size()
        qux,quy=quitimg.get_size()
        bkx,bky=backdir.get_size()
        upx,upy=up_img.get_size()
        downx,downy=down_img.get_size()
        #获取home以及内部存储定义
        home_path=subprocess.run('echo $HOME',capture_output=True,text=True,shell=True,check=True)
        home_path=home_path.stdout[:-1]
        storage_path='/storage/emulated/0'
        if self.path=='':
            ip_path1=''
            dircs=['内部存储','HOME']
        else:
            if storage_path in self.path:
                storage_path2='内部存储'
                ip_path=self.path.replace(storage_path,'')[1:]
                ip_path1=f'{storage_path2}/{ip_path}'
                ip_path0=f'{storage_path}/{ip_path}'
                dircs=os.listdir(ip_path0)
            elif home_path in self.path:
                home_path2='HOME'
                ip_path=self.path.replace(home_path,'')
                ip_path1=f'{home_path2}/{ip_path}'
                ip_path0=f'{home_path}/{ip_path}'
            else:
                ip_path='Path Erreo'
        #定义文件名
        def file_blit(dir_cs,numb,px,py):
            try:
                screen.blit(fonts(55,black,f'{dir_cs[numb]}',14),(px,py))
                pygame.draw.line(screen,black,(0,py+100),(1080,py+100),3)
            except IndexError:
                screen.blit(fonts(55,black,''),(150,400))
        #检测文件夹与文件属性
        def filetypes(filname,imy):
            if self.filetype(filname)=='picture':
                screen.blit(picture,(30,imy))
            elif self.filetype(filname)=='text':
                screen.blit(txt_img,(30,imy))
            elif self.filetype(filname)=='ppt':
                screen.blit(ppt_img,(30,imy))
            elif self.filetype(filname)=='doc':
                screen.blit(doc_img,(30,imy))
            elif self.filetype(filname)=='xls':
                screen.blit(xls_img,(30,imy))
            elif self.filetype(filname)=='zip':
                screen.blit(zip_img,(30,imy))
            elif self.filetype(filname)=='music':
                screen.blit(music_img,(30,imy))
            elif self.filetype(filname)=='video':
                screen.blit(video_img,(30,imy))
            elif self.filetype(filname)=='apk':
                screen.blit(apk_img,(30,imy))
            elif self.filetype(filname)=='html':
                screen.blit(html_img,(30,imy))
            elif self.filetype(filname)=='xmaind':
                screen.blit(xmind_img,(30,imy))
            else:
                screen.blit(weifile,(30,imy))
        filenum=0
        while self.runn:
            if len(ip_path1)>25:
                ip_path2=ip_path1[len(ip_path1)-25:]
            else:
                ip_path2=ip_path1
            screen.fill(white)
            pygame.draw.rect(screen,dqblue,(0,0,1080,200))
            screen.blit(fonts(50,black,'位置:'),(10,50))
            pygame.draw.rect(screen,white,(130,40,750,80))
            pygame.draw.rect(screen,black,(130,40,750,80),3)
            screen.blit(backdir,(890,10))
            pygame.draw.rect(screen,dqblue,(0,2100,1080,235))
            screen.blit(xzfile,(100,2150))
            screen.blit(quitimg,(600,2150))
            screen.blit(up_img,(1000,210))
            screen.blit(down_img,(1000,2010))
            #路径渲染
            screen.blit(fonts(40,black,f'{ip_path2}'),(140,55))
            #文件夹及文件渲染
            if ip_path0=='':
                screen.blit(fonts(55,black,f'{dircs[0]}'),(150,250))
                pygame.draw.line(screen,black,(0,350),(1080,350),3)
                screen.blit(storage_img,(30,240))
            else:
                try:
                    screen.blit(fonts(55,black,f'{dircs[0+12*filenum]}',14),(150,250))
                    pygame.draw.line(screen,black,(0,350),(1080,350),3)
                except IndexError:
                    screen.blit(fonts(55,black,''),(150,250))
                try:
                    path1=f'{ip_path0}/{dircs[0+12*filenum]}'
                    if os.path.isdir(path1)==True:
                        screen.blit(dirs_img,(30,240))
                        pathdir1=True
                    elif os.path.isfile(path1)==True:
                        pathdir1=False
                        try:
                            filetypes(f'{dircs[0+12*filenum]}',240)
                        except IndexError:
                            pass
                    else:
                        pathdir1=None
                except IndexError:
                    pass
            if ip_path0=='':
                screen.blit(fonts(55,black,f'{dircs[1]}'),(150,400))
                pygame.draw.line(screen,black,(0,500),(1080,500),3)
                screen.blit(home_img,(30,390))
            else:
                try:
                    screen.blit(fonts(55,black,f'{dircs[1+12*filenum]}',14),(150,400))
                    pygame.draw.line(screen,black,(0,500),(1080,500),3)
                except IndexError:
                    screen.blit(fonts(55,black,''),(150,400))
                try:
                    path2=f'{ip_path0}/{dircs[1+12*filenum]}'
                    if os.path.isdir(path2)==True:
                        screen.blit(dirs_img,(30,390))
                        pathdir2=True
                    elif os.path.isfile(path2)==True:
                        pathdir2=False
                        try:
                            filetypes(f'{dircs[1+12*filenum]}',390)
                        except IndexError:
                            pass
                    else:
                        pathdir2=None
                except IndexError:
                    pass
            file_blit(dircs,2+12*filenum,150,550)
            try:
                path3=f'{ip_path0}/{dircs[2+12*filenum]}'
                if os.path.isdir(path3)==True:
                    screen.blit(dirs_img,(30,540))
                    pathdir3=True
                elif os.path.isfile(path3)==True:
                    pathdir3=False
                    try:
                        filetypes(f'{dircs[2+12*filenum]}',540)
                    except IndexError:
                        pass
                else:
                    pathdir3=None
            except IndexError:
                pass
            file_blit(dircs,3+12*filenum,150,700)
            try:
                path4=f'{ip_path0}/{dircs[3+12*filenum]}'
                if os.path.isdir(path4)==True:
                    screen.blit(dirs_img,(30,690))
                    pathdir4=True
                elif os.path.isfile(path4)==True:
                    pathdir4=False
                    try:
                        filetypes(f'{dircs[3+12*filenum]}',690)
                    except IndexError:
                        pass
                else:
                    pathdir4=None
            except IndexError:
                pass
            file_blit(dircs,4+12*filenum,150,850)
            try:
                path5=f'{ip_path0}/{dircs[4+12*filenum]}'
                if os.path.isdir(path5)==True:
                    screen.blit(dirs_img,(30,840))
                    pathdir5=True
                elif os.path.isfile(path5)==True:
                    pathdir5=False
                    try:
                        filetypes(f'{dircs[4+12*filenum]}',840)
                    except IndexError:
                        pass
                else:
                    pathdir5=None
            except IndexError:
                pass
            file_blit(dircs,5+12*filenum,150,1000)
            try:
                path6=f'{ip_path0}/{dircs[5+12*filenum]}'
                if os.path.isdir(path6)==True:
                    screen.blit(dirs_img,(30,990))
                    pathdir6=True
                elif os.path.isfile(path6)==True:
                    pathdir6=False
                    try:
                        filetypes(f'{dircs[5+12*filenum]}',990)
                    except IndexError:
                        pass
                else:
                    pathdir6=None
            except IndexError:
                pass
            file_blit(dircs,6+12*filenum,150,1150)
            try:
                path7=f'{ip_path0}/{dircs[6+12*filenum]}'
                if os.path.isdir(path7)==True:
                    screen.blit(dirs_img,(30,1140))
                    pathdir7=True
                elif os.path.isfile(path7)==True:
                    pathdir7=False
                    try:
                        filetypes(f'{dircs[6+12*filenum]}',1140)
                    except IndexError:
                        pass
                else:
                    pathdir7=None
            except IndexError:
                pass
            file_blit(dircs,7+12*filenum,150,1300)
            try:
                path8=f'{ip_path0}/{dircs[7+12*filenum]}'
                if os.path.isdir(path8)==True:
                    screen.blit(dirs_img,(30,1290))
                    pathdir8=True
                elif os.path.isfile(path8)==True:
                    pathdir8=False
                    try:
                        filetypes(f'{dircs[7+12*filenum]}',1290)
                    except IndexError:
                        pass
                else:
                    pathdir8=None
            except IndexError:
                pass
            file_blit(dircs,8+12*filenum,150,1450)
            try:
                path9=f'{ip_path0}/{dircs[8+12*filenum]}'
                if os.path.isdir(path9)==True:
                    screen.blit(dirs_img,(30,1440))
                    pathdir9=True
                elif os.path.isfile(path9)==True:
                    pathdir9=False
                    try:
                        filetypes(f'{dircs[8+12*filenum]}',1440)
                    except IndexError:
                        pass
                else:
                    pathdir9=None
            except IndexError:
                pass
            file_blit(dircs,9+12*filenum,150,1600)
            try:
                path10=f'{ip_path0}/{dircs[9+12*filenum]}'
                if os.path.isdir(path10)==True:
                    screen.blit(dirs_img,(30,1590))
                    pathdir10=True
                elif os.path.isfile(path10)==True:
                    pathdir10=False
                    try:
                        filetypes(f'{dircs[9+12*filenum]}',1590)
                    except IndexError:
                        pass
                else:
                    pathdir10=None
            except IndexError:
                pass
            file_blit(dircs,10+12*filenum,150,1750)
            try:
                path11=f'{ip_path0}/{dircs[10+12*filenum]}'
                if os.path.isdir(path11)==True:
                    screen.blit(dirs_img,(30,1740))
                    pathdir11=True
                elif os.path.isfile(path11)==True:
                    pathdir11=False
                    try:
                        filetypes(f'{dircs[10+12*filenum]}',1740)
                    except IndexError:
                        pass
                else:
                    pathdir11=None
            except IndexError:
                pass
            file_blit(dircs,11+12*filenum,150,1900)
            try:
                path12=f'{ip_path0}/{dircs[11+12*filenum]}'
                if os.path.isdir(path12)==True:
                    screen.blit(dirs_img,(30,1890))
                    pathdir12=True
                elif os.path.isfile(path12)==True:
                    pathdir12=False
                    try:
                        filetypes(f'{dircs[11+12*filenum]}',1890)
                    except IndexError:
                        pass
                else:
                    pathdir12=None
            except IndexError:
                pass
            pygame.display.update()
            time.sleep(1/20)
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    self.runn=False
                elif event.type==pygame.MOUSEBUTTONUP:
                    mx,my=event.pos
                    if 100<=mx<100+xfx and 2150<=my<2150+xfy:
                        self.runn=False
                        return ip_path0
                    elif 600<=mx<600+qux and 2150<=my<2150+quy:
                        self.runn=False
                        return ''
                    elif 890<=mx<890+bkx and 10<=my<10+bky:
                        splitpath=ip_path1.split('/')[-1]
                        ip_path1=ip_path1[:-len(splitpath)-1]
                        filenum=0
                        if ip_path0==storage_path or ip_path0==home_path:
                            ip_path0=''
                            dircs=['内部存储','HOME']
                        elif ip_path0=='':
                            pass
                        else:
                            ip_path0=ip_path0[:-len(splitpath)-1]
                            dircs=os.listdir(ip_path0)
                    elif 1000<=mx<1000+upx and 210<=my<210+upy:
                        filenum-=1
                        if filenum<0:
                            filenum=0
                        else:
                            pass
                    elif 1000<=mx<1000+downx and 2010<=my<2010+downy:
                        if (filenum+1)*12+11>len(dircs)+12:
                            pass
                        else:
                            filenum+=1
                    elif 210<=my<350:
                        if ip_path0=='':
                            ip_path1+='内部存储'
                            ip_path0+='/storage/emulated/0'
                            dircs=os.listdir(ip_path0)
                        else:
                            if pathdir1==True:
                                try:
                                    ip_path1+=f'/{dircs[0+12*filenum]}'
                                    ip_path0+=f'/{dircs[0+12*filenum]}'
                                    dircs=os.listdir(ip_path0)
                                    filenum=0
                                except IndexError:
                                    pass
                            elif pathdir1==False:
                                self.runn=False
                                return f'{ip_path0}/{dircs[0+12*filenum]}'
                            else:
                                pass
                    elif 350<=my<500:
                        if pathdir2==True:
                            if ip_path0=='':
                                ip_path1+='HOME'
                                ip_path0+=f'{home_path}'
                                dircs=os.listdir(ip_path0)
                            else:
                                try:
                                    ip_path1+=f'/{dircs[1+12*filenum]}'
                                    ip_path0+=f'/{dircs[1+12*filenum]}'
                                    dircs=os.listdir(ip_path0)
                                    filenum=0
                                except IndexError:
                                    pass
                        elif pathdir2==False:
                            self.runn=False
                            return f'{ip_path0}/{dircs[1+12*filenum]}'
                        else:
                            pass
                    elif 500<=my<650:
                        if pathdir3==True:
                            try:
                                ip_path1+=f'/{dircs[2+12*filenum]}'
                                ip_path0+=f'/{dircs[2+12*filenum]}'
                                dircs=os.listdir(ip_path0)
                                filenum=0
                            except IndexError:
                                pass
                        elif pathdir3==False:
                            self.runn=False
                            return f'{ip_path0}/{dircs[2+12*filenum]}'
                        else:
                            pass
                    elif 650<=my<800:
                        if pathdir4==True:
                            try:
                                ip_path1+=f'/{dircs[3+12*filenum]}'
                                ip_path0+=f'/{dircs[3+12*filenum]}'
                                dircs=os.listdir(ip_path0)
                                filenum=0
                            except IndexError:
                                pass
                        elif pathdir4==False:
                            self.runn=False
                            return f'{ip_path0}/{dircs[3+12*filenum]}'
                        else:
                            pass
                    elif 800<=my<950:
                        if pathdir5==True:
                            try:
                                ip_path1+=f'/{dircs[4+12*filenum]}'
                                ip_path0+=f'/{dircs[4+12*filenum]}'
                                dircs=os.listdir(ip_path0)
                                filenum=0
                            except IndexError:
                                pass
                        elif pathdir5==False:
                            self.runn=False
                            return f'{ip_path0}/{dircs[4+12*filenum]}'
                        else:
                            pass
                    elif 950<=my<1100:
                        if pathdir6==True:
                            try:
                                ip_path1+=f'/{dircs[5+12*filenum]}'
                                ip_path0+=f'/{dircs[5+12*filenum]}'
                                dircs=os.listdir(ip_path0)
                                filenum=0
                            except IndexError:
                                pass
                        elif pathdir6==False:
                            self.runn=False
                            return f'{ip_path0}/{dircs[5+12*filenum]}'
                        else:
                            pass
                    elif 1100<=my<1250:
                        if pathdir7==True:
                            try:
                                ip_path1+=f'/{dircs[6+12*filenum]}'
                                ip_path0+=f'/{dircs[6+12*filenum]}'
                                dircs=os.listdir(ip_path0)
                                filenum=0
                            except IndexError:
                                pass
                        elif pathdir7==False:
                            self.runn=False
                            return f'{ip_path0}/{dircs[6+12*filenum]}'
                        else:
                            pass
                    elif 1250<=my<1400:
                        if pathdir8==True:
                            try:
                                ip_path1+=f'/{dircs[7+12*filenum]}'
                                ip_path0+=f'/{dircs[7+12*filenum]}'
                                dircs=os.listdir(ip_path0)
                                filenum=0
                            except IndexError:
                                pass
                        elif pathdir8==False:
                            self.runn=False
                            return f'{ip_path0}/{dircs[7+12*filenum]}'
                        else:
                            pass
                    elif 1400<=my<1550:
                        if pathdir9==True:
                            try:
                                ip_path1+=f'/{dircs[8+12*filenum]}'
                                ip_path0+=f'/{dircs[8+12*filenum]}'
                                dircs=os.listdir(ip_path0)
                                filenum=0
                            except IndexError:
                                pass
                        elif pathdir9==False:
                            self.runn=False
                            return f'{ip_path0}/{dircs[8+12*filenum]}'
                        else:
                            pass
                    elif 1550<=my<1700:
                        if pathdir10==True:
                            try:
                                ip_path1+=f'/{dircs[9+12*filenum]}'
                                ip_path0+=f'/{dircs[9+12*filenum]}'
                                dircs=os.listdir(ip_path0)
                                filenum=0
                            except IndexError:
                                pass
                        elif pathdir10==False:
                            self.runn=False
                            return f'{ip_path0}/{dircs[9+12*filenum]}'
                        else:
                            pass
                    elif 1700<=my<1850:
                        if pathdir11==True:
                            try:
                                ip_path1+=f'/{dircs[10+12*filenum]}'
                                ip_path0+=f'/{dircs[10+12*filenum]}'
                                dircs=os.listdir(ip_path0)
                                filenum=0
                            except IndexError:
                                pass
                        elif pathdir11==False:
                            self.runn=False
                            return f'{ip_path0}/{dircs[10+12*filenum]}'
                        else:
                            pass
                    elif 1850<=my<2000:
                        if pathdir12==True:
                            try:
                                ip_path1+=f'/{dircs[11+12*filenum]}'
                                ip_path0+=f'/{dircs[11+12*filenum]}'
                                dircs=os.listdir(ip_path0)
                                filenum=0
                            except IndexError:
                                pass
                        elif pathdir12==False:
                            self.runn=False
                            return f'{ip_path0}/{dircs[11+12*filenum]}'
                        else:
                            pass
                    else:
                        pass
                else:
                    pass